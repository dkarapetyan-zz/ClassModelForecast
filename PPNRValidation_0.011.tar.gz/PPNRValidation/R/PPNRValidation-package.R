#'The PPNRValidation package allows for easy validation of PPNR CCAR models.
#'
#' @name PPNRValidation-package
#' @aliases PPNRValidation
#' @docType package
#' @title Simplified PPNR validation
#' @author Omar Azhar, Anton Bossenbroek, David Karapetyan, Prabakar Rajasekaran
NULL

